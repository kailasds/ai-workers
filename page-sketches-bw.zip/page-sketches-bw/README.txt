AI Worker Platform - page sketches
=================================
Low-fidelity wireframes of every screen. Open the SVG files in any browser.
Black and white: solid black = primary action / current selection.
Grey boxes with dashed lines are placeholders for content.

01 Dashboard
02 Compose steps 1-6 (define, intent, brain, knowledge & growth, definition of done, autonomy)
08 Compose package
09-10 Registry (Workers, Customer packages)
11 Worker detail
12-15 Knowledge (assigned, gained, platform, preview panel)
16 Knowledge detail
17 Knowledge catalogue
18 Learning (activity, gained, evolution)
21 Explore map
22 Detailed reports
23 Sentinel (worker reviews, platform decisions, knowledge health)
